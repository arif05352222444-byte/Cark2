AileCarki_AudioPack_v1 — beklenen dosyalar
Uzantı: .ogg (önerilen), .mp3, .wav veya .m4a
Dosya yoksa oyun sessiz devam eder.

[voice/]
  welcome.ogg   (VOICE_WELCOME)
  spin_prompt.ogg   (VOICE_SPIN_PROMPT)
  correct.ogg   (VOICE_CORRECT)
  wrong.ogg   (VOICE_WRONG)
  bankrupt.ogg   (VOICE_BANKRUPT)
  round_complete.ogg   (VOICE_ROUND_COMPLETE)
  final_intro.ogg   (VOICE_FINAL_INTRO)
  final_win.ogg   (VOICE_FINAL_WIN)
  final_lose.ogg   (VOICE_FINAL_LOSE)

[effect/]
  wheel_spin.ogg   (FX_WHEEL_SPIN)
  wheel_stop.ogg   (FX_WHEEL_STOP)
  letter_reveal.ogg   (FX_LETTER_REVEAL)
  letter_wrong.ogg   (FX_LETTER_WRONG)
  bankrupt.ogg   (FX_BANKRUPT)
  lose_turn.ogg   (FX_LOSE_TURN)
  double.ogg   (FX_DOUBLE)
  correct.ogg   (FX_CORRECT)
  wrong.ogg   (FX_WRONG)
  celebration.ogg   (FX_CELEBRATION)
  timer_tick.ogg   (FX_TIMER_TICK)
  timeout.ogg   (FX_TIMEOUT)

[music/]
  menu.ogg   (MUSIC_MENU)
  game.ogg   (MUSIC_GAME)
  final.ogg   (MUSIC_FINAL)

[ui/]
  move.ogg   (UI_MOVE)
  select.ogg   (UI_SELECT)
  back.ogg   (UI_BACK)
  disabled.ogg   (UI_DISABLED)
